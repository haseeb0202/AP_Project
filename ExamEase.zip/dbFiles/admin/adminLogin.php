<?php

	require_once "connect.php";

	$username = $_POST["username"];
	$password = $_POST["password"];

	//$sql_query = "SELECT name from admin_users WHERE username like '$username' AND password like '$password'";
	$sql_query = "SELECT * from admin_users WHERE username='$username' AND password='$password' ";


	$result = mysqli_query($connection, $sql_query);

	if(mysqli_num_rows($result) > 0)
	{
		$row = mysqli_fetch_assoc($result);
		$name = $row['name'];
		$id = $row['id'];
		
		$response["message"] = "Login Successful...";
		$response["aid"] = $id;
 		echo json_encode($response);
	}
	else
	{
		$response["message"] = "Login Failed";
 		echo json_encode($response);
	}


/*
if($_SERVER['REQUEST_METHOD']=='POST'){
		
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if($username == '' || $password == ''){
			echo 'please fill all values';
		}else{
			require_once('connect.php');
			$sql = "SELECT * FROM admin_users WHERE username='$username' ";
			
			$check = mysqli_fetch_array(mysqli_query($connection,$sql));
			
			if(isset($check)){
				echo 'Login Successful!';
			}

			mysqli_close($connection);
		}
}else{
echo 'error - not receiving POST request';
}
*/

?>