<?php

require_once "connect.php";

$name = $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];



$sql_query = "INSERT into admin_users(name, username, password) VALUES ('$name', '$username', '$password')";

if(mysqli_query($connection, $sql_query))
{
	$response["message"] = "You are registered successfully.";
 	echo json_encode($response);
}
else
{
	$response["message"] = "Something went wrong";
 	echo json_encode($response);
}

/*   IMPLEMENT THIS ONE LATER. have some issues in posting to database.
if($_SERVER['REQUEST_METHOD']=='POST'){
		$name = $_POST['name'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if($name == '' || $username == '' || $password == ''){
			echo 'please fill all values';
		}else{
			require_once('connect.php');
			$sql = "SELECT * FROM admin_users WHERE username='$username' ";
			
			$check = mysqli_fetch_array(mysqli_query($connection,$sql));
			
			if(isset($check)){
				echo 'username already exist';
			}else{				
				$sql = "INSERT INTO admin_users (name,username,password) VALUES('$name','$username','$password')";
				if(mysqli_query($connection,$sql)){
					echo 'Registration Successful';
				}else{
					echo 'oops! Please try again!';
				}
			}
			mysqli_close($connection);
		}
}else{
echo 'error - not receiving POST request';
}
*/

?>