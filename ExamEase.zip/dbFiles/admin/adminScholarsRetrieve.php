<?php


	
	//php script to get information from the database
		
		//first get information from table , then encode information as JASON object
	
	require_once "connect.php";

	$sql_query = "SELECT * FROM scholar_users_temp;";

	$result = mysqli_query($connection, $sql_query);

	//it will get all the rows from table and save it as $result
	// now we have to get each row from result and we have to make each row as a name/value pair 
		//and have to encode the row as JSON Objkect


	$response = array();

	while($row = mysqli_fetch_array($result))
	{
		//we have to now make some name/value pair and convert them to JASON object
		array_push($response, array( "scholar_id"=>$row[0], "name"=>$row[1], "email"=>$row[2], "username"=>$row[3], "password"=>$row[4],
									"sect"=>$row[5], "age"=>$row[6], "contact_number"=>$row[9],
									"profile_pic"=>$row[7], "certificate"=>$row[8] )  );

	}


		// now encode the JSON data as an array

	echo json_encode(array("server_response"=>$response));

	mysqli_close($connection);


?>