<?php

if($_SERVER['REQUEST_METHOD']=='POST'){


	require_once "connect.php";

	//ELSE SHOW THE PROFILE DETAILS TO ADMIN   
	//(OLD - in case if i used the 1st method - see ScholarRequestsAdapter class comments at the very bottom)
	//this will show the profile details to AdminScholarDetails class according to the ID passed
	/*
	if (isset($_POST['scholarid']))
	{
		$id = $_POST['scholarid'];
	
		$sql_query = "SELECT * FROM scholar_users_temp WHERE scholar_id='$id' ";

		$result = mysqli_query($connection, $sql_query);


		$response = array();

		$row = mysqli_fetch_array($result);

		array_push($response, array("scholar_id"=>$row[0], "name"=>$row[1], "email"=>$row[2], "username"=>$row[3],
			"password"=>$row[4], "sect"=>$row[5], "age"=>$row[6],"profile_pic"=>$row[7], "certificate"=>$row[8], 
			"contact_number"=>$row[9]  ) 
					);


			// now encode the JSON data as an array

		echo json_encode(array("server_response"=>$response));
	}
	*/


	//////////////////////////////////////////////////////////////////////////////////////////////////////

	if (isset($_POST['scholarid']) && isset($_POST['scholarusername']) && isset($_POST['acceptscholar']))
	{
		$id = $_POST['scholarid'];
		$username = $_POST['scholarusername'];

		$sql_query = "SELECT * FROM scholar_users_temp WHERE scholar_id = '$id' AND username = '$username' ";

		$result = mysqli_query($connection, $sql_query);

		if(mysqli_num_rows($result) > 0)
		{

			$row = mysqli_fetch_assoc($result);

			$name = $row['name'];
			$email = $row['email'];
			$username = $row['username'];
			$password = $row['password'];
			$sect = $row['sect'];
			$age = $row['age'];
			$contact = $row['contact_number'];

			$profile_pic = $row['profile_pic'];
			$certificate = $row['certificate'];

			
			$sql_query = "INSERT into scholar_users(name, email, username, password, sect, age, contact_number,
					 profile_pic, certificate) 
					VALUES
					('$name', '$email','$username', '$password', '$sect', '$age', '$contact', '$profile_pic', '$certificate')";

			if(mysqli_query($connection, $sql_query))
			{
				$sql_query = "DELETE FROM scholar_users_temp WHERE scholar_id='$id' AND username='$username' ";
				if(mysqli_query($connection, $sql_query))
				{		
					$response["message"] = "This Scholar has been Successfully Approved";
			 		echo json_encode($response);
				}
				else
				{
					$response["message"] = "Some Problem Approving the Scholar - Delete Query From Temp Table Failed to Run";
			 		echo json_encode($response);
				}

			}
			else
			{
				$response["message"] = "INSERT Query Failed to Run";
			 	echo json_encode($response);
			}


		}
		else
		{
			$response["message"] = "No Scholar Found with the given username and ID";
			echo json_encode($response);
		}


	}
	else
	{
		$response["message"] = "ID, Username or Accept Key is missing or not provided.";
		echo json_encode($response);
	}




	mysqli_close($connection);
}
else{
		echo 'error - not receiving POST request';
	}


?>