<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once "../connect.php";

		$qid = $_POST['QID'];
		//$qid = "43";
		$response = array();


		$sql_query = "SELECT * FROM questions_answered WHERE q_id = '$qid' ";
		if($result = mysqli_query($connection, $sql_query))	//this line always runs regardless of there are any rows returnedor not
		{

			while($row = mysqli_fetch_assoc($result))
			{
				//GETTING SCHOLAR PIC, NAME and USERNAME
				$scholarUsername = $row['s_username'];
				$sql_query2 = "SELECT profile_pic, name, username FROM scholar_users WHERE username = '$scholarUsername' ";
				$result2 = mysqli_query($connection, $sql_query2);
				$row2 = mysqli_fetch_assoc($result2);

				array_push($response, array("s_pic"=>$row2['profile_pic'], "s_name"=>$row2['name'], "s_username"=>$row2['username'],
											  "answer"=>$row['answer'] )  );

			}
		}
		else
		{
			echo "QUERY DONT RUNS";
		}


		echo json_encode(array("server_response"=>$response));

		mysqli_close($connection);

	}
	else
		echo "NOT RECEIVING POST REQUEST";





?>