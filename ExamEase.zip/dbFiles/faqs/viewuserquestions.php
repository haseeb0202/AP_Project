<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once "../connect.php";

		$userid = $_POST["userid"];
		//$userid = "20";

		$sql_query = "SELECT * FROM questions_asked WHERE user_id = '$userid' ";
		if($result = mysqli_query($connection, $sql_query))
		{
			$response = array();

			while($row = mysqli_fetch_array($result))
			{
				$QID = $row['q_id'];	//getting q_id from questions_asked table;
				
				//checking if the question according to q_id is answered in questions_answered table;
				$sql_query2 = "SELECT * FROM questions_answered WHERE q_id = '$QID' AND answer NOT LIKE 'UNANSWERED' ";
				/*
				In the above query, we only need to check if any of the rows match with the query, that means if query returns
				more than 0 rows (e.g 1) then it means some scholar has answered this question -- so now send flag = answered
				with the response array push so i can show the TICK icon with the question, that means this question is answered.
				and user can instantly see in the view questions list view in android that which question is answered.
				AS SIR ASKED ME SPECIFICALLY TO DO.
				*/
				if($result2 = mysqli_query($connection, $sql_query2))	//this line always runs
				{
					//if the question is answered - get all the rows - 
					//(there will be more than 1 rows if the question is asked to more than 1 scholars)
					//e.g let say we got 2 row in return, we will then get the scholar username column and answer coulm
					//if($row2 = mysqli_fetch_array($result2))
					if( ($row2 = mysqli_fetch_array($result2) ) > 0)	//means if rows returned are 1 or more
					{
						array_push($response, array("q_id"=>$row['q_id'], "question"=>$row['question'], "category"=>$row['category'],
														"flag"=>"answered", "user_id"=>$row['user_id'] ) );
					}
					else
					{
						array_push($response, array("q_id"=>$row['q_id'], "question"=>$row['question'], "category"=>$row['category'],
														"flag"=>"unanswered", "user_id"=>$row['user_id']) );
							/*flag is passed in array to check in android code if its answered or not
							if its answered then i will show the TICK in the questions list view so user can know its
							answered by one of the scholar he/she asked to.
							-----
							and user_id is being passed here so I can allow only the user who asked the question to be able
							to edit the question as well. For example if my user_id is 20 and I am logged in then only
							I can edit the question by going in 'View questions' option in android code or also going to 
							general FAQS Home screen category wise if i view question then there also i will be allowed to edit
							my question CUZ i am using same class 'QuestionsDetails.cass' for view questions details
							in user's own view questions AND also for general public/all other users.
							-----10Jan2017 --Thanks Dear GOD for putting all this great ideas today in my mind.
							*/
					}
					

				}	//end of result2 if
				
				//array_push($response, array("q_id"=>$row['q_id'], "question"=>$row['question'], "category"=>$row['category']) );


			}	//end of while loop


		}



		echo json_encode(array("server_response"=>$response));

		mysqli_close($connection);

	}
	else
		echo "NOT RECEIVING POST REQUESt";


?>