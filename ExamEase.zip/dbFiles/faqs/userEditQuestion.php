<?php



	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once "../connect.php";

		$qid 		= $_POST['qid'];
		$question	= $_POST['questionedit'];
		$userid 	= $_POST['userid'];

		$sql_query = "UPDATE questions_asked SET question = '$question' WHERE q_id = '$qid' AND user_id = '$userid' ";
		if(mysqli_query($connection, $sql_query))
		{
			$response['message'] = "This Question is Updated Sucessfully";
			echo json_encode($response);
		}

		mysqli_close($connection);


	}
	else
		echo "NOT RECEIVING POST REUQEST";




?>