<?php



	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once "../connect.php";

		$qid 		= $_POST['qid'];
		$susername 	= $_POST['susername'];
		$answer 	= $_POST['answer'];

		$sql_query = "UPDATE questions_answered SET answer = '$answer' WHERE q_id = '$qid' AND s_username = '$susername' ";
		$sql_query2 = "SELECT * FROM questions_answered";

		if(mysqli_query($connection, $sql_query))
		{
			$response['message'] = "Your answer has been successfully added.";
			echo json_encode($response);
		}
		else
		{
			$response['message'] = "Failed to add the answer.";
			echo json_encode($response);
		}

		mysqli_close($connection);


	}
	else
		echo "NOT RECEIVING POST REQUEST";





?>