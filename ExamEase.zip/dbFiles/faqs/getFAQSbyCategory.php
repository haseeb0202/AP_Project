<?php


	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		require_once "../connect.php";

		$category = $_POST['faqcategory'];

		$sql_query = "SELECT * FROM questions_asked WHERE category = '$category' ";
		if($result = mysqli_query($connection, $sql_query))
		{
			$response = array();

			while($row = mysqli_fetch_array($result))
			{
				array_push($response, array("q_id"=>$row['q_id'], "question"=>$row['question'], "category"=>$row['category'] ) );
			}

		}

		

		echo json_encode(array("server_response"=>$response));

		mysqli_close($connection);


	}
	else
		echo "NOT RECEIVING POST REQUEST";





?>