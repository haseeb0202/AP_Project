<?php


	if ($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		require_once "../connect.php";

		$userid 	= $_POST["userid"];
		$category 	= $_POST["category"];
		$question	= $_POST["question"];

		//to get all scholars username that the users have selected in the list
		$scholarusers	= array();

		$count		= (int)$_POST["scholarscount"];
		$index = $count;
		while($count != 0)
		{
			$scholarusers[$count] = $_POST["selectedscholar"."$count"];
			$count--;
		}



		$sql_query1 = "INSERT INTO questions_asked (category, question, user_id) VALUES ('$category', '$question', '$userid') ";
		if(mysqli_query($connection, $sql_query1))
		{
			$last_id = mysqli_insert_id($connection);

			while($index > 0)
			{
				$susername = $scholarusers[$index];

				$sql_query2 = "INSERT INTO questions_answered (q_id, s_username, answer, user_id) 
											VALUES ('$last_id', '$susername', 'UNANSWERED', '$userid') ";
				mysqli_query($connection, $sql_query2);
				$index--;
			}

			$response["message"] = "Your Question has been asked.";
			echo json_encode($response);

		}
		else
		{
			$response["message"] = "SQL QUERY 1 FAILED TO RUN";
			echo json_encode($response);
		}


	}
	else
		echo "NOT RECEIVING POST REQUEST";




?>