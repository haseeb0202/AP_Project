<?php


	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once('../connect.php');

		$sid 		= $_POST['scholarid'];
		$sname 		= $_POST['scholarname'];
		//name column added later cuz in FAQ home user should know that this question is answered by which scholar
		$question 	= $_POST['question'];
		$answer 	= $_POST['answer'];
		$category	= $_POST['category'];

		$sql_query = "INSERT INTO faqs (scholar_id, question, answer, category, scholar_name) 
						VALUES ('$sid', '$question', '$answer', '$category', '$sname' ) ";

		if(mysqli_query($connection, $sql_query))
		{
			$response["message"] = "FAQ Successfully Added";
			echo json_encode($response);
		}
		else
		{
			$response["message"] = "QUERY FAILED TO RUN - INSERTION FAILED";
			echo json_encode($response);
		}


		mysqli_close($connection);



	}	//END OF IF REQUEST_POST == POST 
	else
		echo "NOT RECEIVING POST REQUEST";







?>