<?php

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once "../connect.php";

		$sid 		= $_POST['sid'];
		$susername 	= $_POST['susername'];

		//$susername = "abdulhaq.qadri";

		//TO GET QUESTIONS ASKED TO A SPECIFIC SCHOLARS, THE LOGIC HERE IS TO FIRST GET ALL THE QIDs AGAINST S_USERNAME
		//FROM questions_answered TABLE & THEN MATCH THE QID AGAINST ROW IN questions_asked table TO GET ALL QUESTIONS
		//ASKED TO THAT SCHOLAR
		$get_qids = "SELECT q_id,answer FROM questions_answered WHERE s_username = '$susername' ";
		$result = mysqli_query($connection, $get_qids);
		$questionIDS = array();
		
		$answers = array();	
		/* 
		this line is added later when i needed to retrieve the answers by scholars so i was gonna created new script
		but then i thought why not retrieve the answers of scholars from answers table from this script along with
		questions retrieval - so it wud be FASTER. wud not need to again load answers from another script with another
		new http call from android side blah blah --- 8thApril2016 -- (Anniversary 10 years of Memories of 8AP2006)
		*/

		$index = 0;

		while($row = mysqli_fetch_array($result))
		{
			$questionIDS[$index] = $row;	//old line was just $questionIDS[$index] = $row
			$answers[$index] = $row;		//#NEW
			$index++;
		}
		//THE ABOVE LOOP WILL GET ALL THE Q_IDs against the SCHOLAR USERNAME SO WE KNOW THAT SCHOLAR X IS ASKED WAT QIDS


		$response = array();

		while($index > 0)
		{
			$qid = $questionIDS[$index-1][0];
			$ans = $answers[$index-1][1];		//#NEW --we already got the answers against a q_id
			$sql_query2 = "SELECT * FROM questions_asked WHERE q_id = '$qid' ";
			$result2 = mysqli_query($connection, $sql_query2);
			$row2 = mysqli_fetch_assoc($result2);
			array_push($response, array("q_id"=>$row2['q_id'], "category"=>$row2['category'], "question"=>$row2['question'], 
												"user_id"=>$row2['user_id'], "answer"=>$ans ) );

			$index--;

		}



/*
		if($result = mysqli_query($connection, $sql_query))
		{
			$response = array();
			while($row = mysqli_fetch_assoc($result))
			{
				$qid = $row['q_id'];
				$sql_query2 = "SELECT * FROM questions_asked WHERE q_id = '$qid' ";
				$result = mysqli_query($connection, $sql_query2);

			}
		}
*/


		echo json_encode(array("server_response"=>$response));

		mysqli_close($connection);

	}
	else
		echo "NOT RECEIVING POST REUQEST";





?>