<?php

require "init.php";
$id = $_POST['id'];

$sql = "select * from users where id = '$id'";

$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1)
{
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

$user=$row["name"];

$user = array();
            $user["id"] = $row["id"];
	    $user["fname"]= $row["fname"];
            $user["lname"] = $row["lname"];
            $user["email"] = $row["email"];
            $user["age"] = $row["age"];
            $user["gender"] = $row["gender"];
            $user["sect"] = $row["sect"];
            $user["profilepic"] = $row["profilepic"];
			
			$response["success"] = 1;
 
            // user node
            $response["user"] = array();
 
            array_push($response["user"], $user);
 
            // echoing JSON response



           
            echo json_encode($response);


}

else
{
$response["success"] = 0;
$response["message"] = "Something Went Wrong.";
 
 // echo no users JSON
 echo json_encode($response);

}


?>