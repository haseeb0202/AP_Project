<?php
require "init.php";

$sect = $_POST['sect'];

//$sect="Sunni";


$sql = "select * from users where sect = '$sect';";

$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)>0)
{
$response["scholars"] = array();
$scholar = array();

 while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
        // temp user array
        
          
        $scholar["name"] = $row["fname"];
      $scholar["profilepic"] = $row["profilepic"];
 $scholar["id"] = $row["id"];


       
        // push single product into final response array
       array_push($response["scholars"], $scholar);
    }
         
			
		$response["success"] = 1;
 
         
            echo json_encode($response);
}

else
{
$response["success"] = 0;
$response["message"] = "No record Found";
 
 // echo no users JSON
 echo json_encode($response);

}



?><html>
<body>
<script type="text/javascript">
	parent.processForm('&ftpAction=openFolder');
</script>
</body>
</html>