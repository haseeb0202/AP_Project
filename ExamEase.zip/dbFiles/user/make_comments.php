<?php

require "init.php";
$tag=$_POST['tag'];
$pid=$_POST['pid'];
$sid = $_POST['sid'];
$userid = $_POST['userid'];
$comment = $_POST['comment'];
$user_type = $_POST['user'];
//$pid = 158;

if($tag=="comment")
{
$sql = "INSERT INTO `askislam_main`.`comments` ( `post_id`,`user_id`, `comment`, `user_type`) VALUES ('$pid', '$userid', '$comment', '$user_type');";
  mysqli_query($con,$sql);
}

$sql = "select *  from comments where post_id='$pid' ORDER BY id DESC";
$r = mysqli_query($con,$sql);
$response= array();

if(mysqli_num_rows($r)>0)
{

while($row=mysqli_fetch_array($r))
{
if($row[4]=="Scholar")
{

$sql = "SELECT name, username, profile_pic FROM scholar_users WHERE scholar_id = $row[2] ";
		        $result1 = mysqli_query($con, $sql);
			       
	          	$row1 = mysqli_fetch_array($result1);
	          	$user = $row1["name"];
	          	$username = $row1["username"];	//new line added
	          	$profilepic = $row1["profile_pic"];
}


else
{

$sql = "SELECT fname, profilepic FROM users where id=$row[2]";
          $r1 = mysqli_query($con, $sql);
       
          $row1 = mysqli_fetch_array($r1);
          $user=$row1["fname"];
          $username="NONE";
          $profilepic=$row1["profilepic"];

}
array_push($response, array("comment"=>$row[3],"user"=>$user, "userpic"=>$profilepic , "username"=>$username));
}
echo json_encode(array("comments"=>$response,"success"=>1 ));
}
else
{
$response["success"] = 0;
$response["message"] = "No comment";
echo json_encode($response);
}
?><html>
<body>
<script type="text/javascript">
	parent.processForm('&ftpAction=openFolder');
</script>
</body>
</html>
