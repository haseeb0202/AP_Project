<?php

require "init.php";
$tag=$_POST['tag'];
$sid = $_POST['id'];
$uid = $_POST['uid'];
//$sid = 5;
//$uid = 90;

$sql = "select * from follow where scholar_id='$sid'";
$r = mysqli_query($con,$sql);
$followers= mysqli_num_rows($r);

//getting posts
$sql_query = "SELECT * FROM scholar_posts where scholar_id ='$sid'";

$resultp = mysqli_query($con, $sql_query);

$post = array();
if(mysqli_num_rows($resultp)>0)
{       $scholarname="";
          $scholarpic="";

	

	while($row = mysqli_fetch_array($resultp))
	
	{
          $sqls = "SELECT name, profile_pic FROM scholar_users where scholar_id=$row[1]";
          $rs1 = mysqli_query($con, $sqls);
       
          $row1 = mysqli_fetch_array($rs1);
          $scholarname=$row1["name"];
          $scholarpic=$row1["profile_pic"];
        

	array_push($post, array("post_id"=>$row[0],"scholar_id"=>$row[1],"post"=>$row[2], "image"=>$row[3], "scholarname"=>$scholarname,"scholarpic"=> $scholarpic ) );
	
	}
}


else
{
array_push($post, array("post"=>"NONE_POSTS_SCHOLAR") );	
}



//$tag="check";

if($tag=="check")
{
$response["followers"]=$followers;
$response["post"]=$post;
$sql = "select * from follow where scholar_id='$sid' AND user_id='$uid';";
$result = mysqli_query($con,$sql);
if(mysqli_num_rows($result)==1)
{
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$response["success"] = 1;
$response["message"] = "unfollow";
 // echo no users JSON
echo json_encode($response);
}

else
{

$response["message"] = "follow";
$response["followers"]=$followers;
$response["post"]=$post;
 // echo no users JSON
 echo json_encode($response);
}


}


if($tag=="follow")
{
$sql_query="INSERT INTO `askislam_main`.`follow` ( `scholar_id`,`user_id`) VALUES ('$sid','$uid');";

if(mysqli_query($con,$sql_query))
{

$response["message"] = "Following";
$response["id"] = mysqli_insert_id($con);
$response["success"] = 1;
 
 // echo no users JSON
 echo json_encode($response);



}

else
{
$response["message"] = "Something went wrong";
 
 // echo no users JSON
 echo json_encode($response);
}

}


//

if($tag=="unfollow")
{
$sql_query="DELETE FROM follow WHERE scholar_id='$sid' AND user_id='$uid';";

if(mysqli_query($con,$sql_query))
{

$response["message"] = "Unfollowing Success";
$response["success"] = 1;
 
 // echo no users JSON
 echo json_encode($response);

}

}

?>