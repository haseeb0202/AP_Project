<?php
require_once "init.php";

$uid=$_POST["uid"];

$sql = "select scholar_id from follow where user_id='$uid'";
$r = mysqli_query($con,$sql);
$followers= array();

while($row=mysqli_fetch_array($r,MYSQLI_ASSOC))
{
array_push($followers,$row['scholar_id']);
}



$sql_query = "SELECT * FROM scholar_posts where scholar_id in (" . implode(",", $followers) . ")";

	$result = mysqli_query($con, $sql_query);

if(mysqli_num_rows($result)>0)
{       $scholarname="";
          $scholarpic="";

	$response = array();

	while($row = mysqli_fetch_array($result))
	
	{
          $sql = "SELECT name, profile_pic FROM scholar_users where scholar_id=$row[1]";
          $r1 = mysqli_query($con, $sql);
       
          $row1 = mysqli_fetch_array($r1);
          $scholarname=$row1["name"];
          $scholarpic=$row1["profile_pic"];
        

	array_push($response, array("post_id"=>$row[0],"scholar_id"=>$row[1],"post"=>$row[2], "image"=>$row[3], "scholarname"=>$scholarname,"scholarpic"=> $scholarpic ) );
	
	}
	echo json_encode(array("post"=>$response,"success"=>1 ));

}

else
{
echo json_encode(array("success"=>1,"message"=>"No Posts" ));
}
?>