<?php
require "init.php";

$tag = $_POST['tag'];
$id=$_POST['id'];


/*$id=68;
$tag="update";

$fname ="Rubina";
$lname ="Batool";
$email = "ruby@gmail.com";
$age = "10";
$gender = "Female";
$sect = "Shia";*/



if($tag=="update")
{
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$sect = $_POST['sect'];
$password = $_POST['password'];
$Image=$_POST['profilepic'];

 $path1 = "userpictures/$id.png";
$profile_pic = "http://amber.webs.net.pk/~askislam/userscripts/$path1";

if($Image=="NONE")
			{



$sql_query="UPDATE  `askislam_main`.`users` SET  `fname` =  '$fname',
`lname` =  '$lname',
`email` =  '$email',
`password` =  '$password',
`age` =  '$age',
`sect` =  '$sect'
 WHERE  `users`.`id` =$id;";

}
else
{

$sql_query="UPDATE  `askislam_main`.`users` SET  `fname` =  '$fname',
`lname` =  '$lname',
`email` =  '$email',
`password` =  '$password',
`age` =  '$age',
`sect` =  '$sect',
`profilepic` = '$profile_pic' WHERE  `users`.`id` =$id;";

}



if(mysqli_query($con,$sql_query))
{

if($Image != "NONE"&& $Image !=null)
				{
					file_put_contents($path1,base64_decode($Image));
				}



$response["message"] = "Information is updated successfully.";

 
}

else
{
$response["message"] = "Something went wrong.";
 
}


}


$sql = "select * from users where id = '$id'";

$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1)
{
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

$user=$row["name"];

$user = array();
            $user["id"] = $row["id"];
	    $user["fname"]= $row["fname"];
            $user["lname"] = $row["lname"];
            $user["email"] = $row["email"];
            $user["age"] = $row["age"];
            $user["gender"] = $row["gender"];
            $user["sect"] = $row["sect"];
            $user["profilepic"] = $row["profilepic"];
            $user["password"] = $row["password"];
			
			$response["success"] = 1;
 
            // user node
            $response["user"] = array();
 
            array_push($response["user"], $user);
 
            // echoing JSON response



           
            echo json_encode($response);


}

else
{
$response["success"] = 0;
$response["message"] = "Something Went Wrong.";
 
 // echo no users JSON
 echo json_encode($response);

}








?>