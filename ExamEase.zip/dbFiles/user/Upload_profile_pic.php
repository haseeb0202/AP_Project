<?php 
require_once('init.php');
 
$image = $_POST['image'];
$id=$_POST['id'];
 $path1 = "userpictures/$id.png";
$profile_pic = "http://amber.webs.net.pk/~askislam/userscripts/$path1";

$sql="UPDATE `askislam_main`.`users` SET `profilepic` = '$profile_pic' where id = '$id'";
 
if(mysqli_query($con,$sql)){
					
					if($image != null )
					{
						file_put_contents($path1,base64_decode($image));
						
					}
 $response["user"] = array();

$sql = "select * from users where id = '$id'";

$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1)
{
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

$user=$row["name"];

$user = array();
            $user["id"] = $row["id"];
	    $user["fname"]= $row["fname"];
            $user["lname"]= $row["lname"];
            $user["email"] = $row["email"];
            $user["profilepic"] = $row["profilepic"];
 
            // user node
           
            array_push($response["user"], $user);



}


$response["message"] = "Image Uploaded Successfully";
$response["success"] = 1;
 
 // echo no users JSON
 echo json_encode($response);
 }else{


$response["message"] = "Error Uploading Image";
$response["success"] = 0;
 
 
 // echo no users JSON
 echo json_encode($response);


 }

 
 ?>