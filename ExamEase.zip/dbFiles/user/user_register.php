<?php
require "init.php";
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$sect = $_POST['sect'];

/*$fname = "123";
$lname = "123";
$email = "1236";
$password = "123";
$age = 12;
$gender = "123";
$sect ="123";*/


$sql = "select * from users where email = '$email'";

$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)>0)
{
$response["message"] = "Email Already Exist";
 
 // echo no users JSON
 echo json_encode($response);

}

else
{
$sql_query="INSERT INTO `askislam_main`.`users` ( `fname`,`lname`, `email`, `password`, `age`, `gender`, `sect`) VALUES ('$fname','$lname', '$email', '$password', '$age', '$gender', '$sect');";
if(mysqli_query($con,$sql_query))
{

$response["message"] = "You are registered successfully.";
$response["success"] = 1;
$response["id"] = mysqli_insert_id($con);


 // echo no users JSON
 echo json_encode($response);



}

else
{
$response["message"] = "Something went wrong";
 
 // echo no users JSON
 echo json_encode($response);
}
}


?>