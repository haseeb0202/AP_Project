<?php
	
if($_SERVER['REQUEST_METHOD']=='POST'){

		$sid = $_POST['scholarid'];
		$scholarPost = $_POST['post'];
		

		require_once('connect.php');
		////////////////////////////////////////////////////////////////
		if(isset($_POST['postpic']))
		{
			$num = mt_rand(10,100);
			$fileImage = $_POST['postpic'];
			$path = "postImages/$sid-$num.png";
			$fileImagePath = "http://amber.webs.net.pk/~askislam/scholarScripts/$path";
			//if i could somehow get the post id of the next row that is going to be inserted then i could
			//save the post image path with postid_scholarid_randomNum  
		}
		else
		{
			$fileImagePath = "NONE";
		}	


		//$sql = "SELECT username FROM scholar_users_temp WHERE username='$username' ";


		$sql_query = "INSERT into scholar_posts(scholar_id, post, file) VALUES ('$sid', '$scholarPost', '$fileImagePath') ";			

		if(mysqli_query($connection, $sql_query)){
			if($fileImage != null)
				file_put_contents($path,base64_decode($fileImage));

			$response["message"] = "This Post has been Successfully Posted";
			echo json_encode($response);
		}else{
			$response["message"] = "Something went wrong";	
			echo json_encode($response);
		}

		mysqli_close($connection);

	}
	else{
		echo 'error - not receiving POST request';
	}

?>