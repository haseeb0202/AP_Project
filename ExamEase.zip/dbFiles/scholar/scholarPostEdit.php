<?php
  

if($_SERVER['REQUEST_METHOD']=='POST'){

	require_once "connect.php";



	//IF POST IS BEING EDITED - updating MYSQL TABLE AND DELETING PIC FROM (postImages) FOLDER WHERE ITS SAVED
	if(isset($_POST['postupdate']) && isset($_POST['postid']) && isset($_POST['scholarid']) )
	{
			$postupdate = $_POST['postupdate'];
			$postID = $_POST['postid'];
			$sid = $_POST['scholarid'];

			$fileImage = null;

			//if scholar has set the new image to the post while editing && there also exist old image
			if(isset($_POST['postpic']) && isset($_POST['existingpicpath']) )	//getting path of existing image to replace it with new
			{
				$fileImage = $_POST['postpic'];
				$existingpicpath = $_POST['existingpicpath'];	//it will be whole URL like http://......./postImages/etc.png
				//so i first get the basename path i.e only the image name
				$basename = basename($existingpicpath);
				$path = "postImages/" . $basename;

				$imgPath = "http://amber.webs.net.pk/~askislam/scholarScripts/$path";
				$sql_query = "UPDATE scholar_posts SET post='$postupdate', file='$imgPath' WHERE post_id='$postID' ";

			}
			//only new image is attached by scholar and there is no old image exist with that post
			elseif (isset($_POST['postpic']) )
			{
				$num = mt_rand(10,100);
				$fileImage = $_POST['postpic'];
				//$path = "postImages/$postID.png";
				$path = "postImages/$sid-$num.png";
				$imgPath = "http://amber.webs.net.pk/~askislam/scholarScripts/$path";

				$sql_query = "UPDATE scholar_posts SET post='$postupdate', file='$imgPath' WHERE post_id='$postID' ";

				
			}
			else 	//if no new image is selected by scholar while editing
			{
				$sql_query = "UPDATE scholar_posts SET post='$postupdate' WHERE post_id='$postID' ";
			}



			if(mysqli_query($connection, $sql_query))
			{	
				if ($fileImage != null) 
					file_put_contents($path,base64_decode($fileImage));

				$response["message"] = "Post Edited Successfully";
		 		echo json_encode($response);
			}

	}
	elseif (isset($_POST['deletepic'])) {
		# code...if scholar only deletes the picture from edit post.
		$imgPath = $_POST['deletepic'];	//by providing key we get the value
		$basename = basename($imgPath);
		$imgPathExtracted = "postImages/" . $basename;

		$sql_query = "UPDATE scholar_posts SET file='NONE' WHERE file='$imgPath' ";

		if(mysqli_query($connection, $sql_query))
		{
				if ($imgPath != "NONE")
				{
					if (file_exists($imgPathExtracted))
					{
						if(!unlink($imgPathExtracted))
						{
							$response["message"] = "Error Deleting Image";
				 			echo json_encode($response);
						}
						else
						{
				 			$response["message"] = "Image Successfully Deleted";
				 			echo json_encode($response);
						}
						
					}
					else
					{
						$response["message"] = "File Exists but Can't be Deleted";
				 		echo json_encode($response);
					}

				}
				else
				{
					$response["message"] = "No Image Exists";
			 		echo json_encode($response);
				}

		}




	}
	//ELSE SHOW/LOAD THE POST THAT IS TO BE EDITED
	elseif (isset($_POST['postid'])) 
	{
		$postID = $_POST['postid'];
	
		$sql_query = "SELECT * FROM scholar_posts WHERE post_id='$postID' ";

		$result = mysqli_query($connection, $sql_query);


		$response = array();

		$row = mysqli_fetch_array($result);

		array_push($response, array("post_id"=>$row[0], "post"=>$row[2], "image"=>$row[3]  ) );


			// now encode the JSON data as an array

		echo json_encode(array("server_response"=>$response));
	}
	
	

	mysqli_close($connection);
}
else{
		echo 'error - not receiving POST request';
	}


?>