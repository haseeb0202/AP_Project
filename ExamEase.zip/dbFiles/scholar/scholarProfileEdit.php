<?php


if($_SERVER['REQUEST_METHOD']=='POST')
{
	require_once "connect.php";

	//IF PROFILE IS BEING EDITED - updating MYSQL TABLE AND DELETING PIC FROM (scholarPictures) FOLDER WHERE ITS SAVED
	if(isset($_POST['profileupdate']) && isset($_POST['scholarid']))
	{
			$profileupdate = $_POST['profileupdate'];
			$profileID = $_POST['scholarid'];
			
			$name = $_POST['name'];
			$email = $_POST['email'];
			$username = $_POST['username'];
			$password = $_POST['password'];
			$sect = $_POST['sect'];
			$age = $_POST['age'];
			$contact = $_POST['contact'];
			$image = $_POST['image'];
			$certificate = $_POST['certificate'];

			$sql_query = "";
			$path = "";
			$path2 = "";
			$path3 = "";

			if($image != null || $certificate != null)
			{
				$path = "$username.png";
				$path2 = "scholarPictures/$username.png";
				$path3 = "scholarCertificates/$username.png";
				
				$profile_pic = "http://amber.webs.net.pk/~askislam/scholarScripts/$path2";
				$certificate_path = "http://amber.webs.net.pk/~askislam/scholarScripts/$path3";

				//Query if scholar wants to update profile pic and or certificate
				$sql_query = "UPDATE scholar_users SET name='$name', email='$email', password='$password', 
				sect='$sect', age='$age', contact_number='$contact', profile_pic='$profile_pic', certificate='$certificate_path'
				WHERE scholar_id='$profileID' ";		


			}
			else
			{
				//query if scholar only wants to edit profile info and not the profile pic
				$sql_query = "UPDATE scholar_users SET name='$name', email='$email', password='$password', 
							sect='$sect', age='$age', contact_number='$contact' WHERE scholar_id='$profileID' ";

			}



			if(mysqli_query($connection, $sql_query)){

				if($image != null && $certificate != null)
				{
					file_put_contents($path2,base64_decode($image));
					file_put_contents($path3,base64_decode($certificate));	
				}
				elseif($image != null)
				{
					file_put_contents($path2,base64_decode($image));
				}
				elseif($certificate != null)
				{
					file_put_contents($path3,base64_decode($certificate));
				}
				
				$response["message"] = "Your Profile is Updated Successfully";
				echo json_encode($response);
			}else{
					$response["message"] = "Something went wrong";	
					echo json_encode($response);
			}


	}
	elseif (isset($_POST['deletepic'])) {
		# code...
		$imgPath = $_POST['deletepic'];	//by providing key we get the value
		$basename = basename($imgPath);
		$imgPathExtracted = "scholarPictures/" . $basename;

		$sql_query = "UPDATE scholar_users SET profile_pic=null WHERE profile_pic='$imgPath' ";

		if(mysqli_query($connection, $sql_query))
		{
				if ($imgPath != null)
				{
					if (file_exists($imgPathExtracted))
					{
						if(!unlink($imgPathExtracted))
						{
							$response["message"] = "Error Deleting Image";
				 			echo json_encode($response);
						}
						else
						{
				 			$response["message"] = "Profile Picture Successfully Deleted";
				 			echo json_encode($response);
						}
						
					}
					else
					{
						$response["message"] = "File Exists but Can't be Deleted";
				 		echo json_encode($response);
					}

				}
				else
				{
					$response["message"] = "No Image Exists";
			 		echo json_encode($response);
				}

		}




	}
	//ELSE SHOW THE PROFILE THAT IS TO BE EDITED
	//elseif (isset($_POST['post'])) 
	elseif (isset($_POST['scholarid']))
	{
		$id = $_POST['scholarid'];
	
		$sql_query = "SELECT * FROM scholar_users WHERE scholar_id='$id' ";

		$result = mysqli_query($connection, $sql_query);


		$response = array();

		$row = mysqli_fetch_array($result);

		array_push($response, array("scholar_id"=>$row[0], "name"=>$row[1], "email"=>$row[2], "username"=>$row[3],
			"password"=>$row[4], "sect"=>$row[5], "age"=>$row[6],"profile_pic"=>$row[7], "certificate"=>$row[8], 
			"contact_number"=>$row[9]  ) 
					);


			// now encode the JSON data as an array

		echo json_encode(array("server_response"=>$response));
	}
	
	

	mysqli_close($connection);
}
else{
		echo 'error - not receiving POST request';
	}


?>