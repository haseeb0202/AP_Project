<?php


	
	if($_SERVER['REQUEST_METHOD']=='POST'){

	
		require_once "connect.php";

		$sid = $_POST['scholarid'];


		$sql_query = "SELECT * FROM scholar_posts WHERE scholar_id = '$sid' ORDER BY post_id DESC";

		$result = mysqli_query($connection, $sql_query);


		//it will get all the rows from table and save it as $result
		// now we have to get each row from result and we have to make each row as a name/value pair 
			//and have to encode the row as JSON Objkect

		$response = array();

		while($row = mysqli_fetch_array($result))
		{
			//we have to now make some name/value pair and convert them to JASON object
			array_push($response, array("post_id"=>$row[0], "post"=>$row[2], "image"=>$row[3]  ) );
		}


			// now encode the JSON data as an array

		echo json_encode(array("server_response"=>$response));

		mysqli_close($connection);
	}
	else
	{
		echo 'error - not receiving POST request';
	}


?>