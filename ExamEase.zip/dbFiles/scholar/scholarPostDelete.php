<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){

		//$scholarDeletePost = $_POST['post'];
		$postID = $_POST['postid'];



		require_once('connect.php');
		////////////////////////////////////////////////////////////////
		

		//$sql_query1 = "SELECT * FROM scholar_posts WHERE post='$scholarDeletePost' ";	
		$sql_query1 = "SELECT * FROM scholar_posts WHERE post_id='$postID' ";


		$result = mysqli_query($connection, $sql_query1);

		if(mysqli_num_rows($result) > 0)
		{
			$row = mysqli_fetch_assoc($result);
			//$postID = $row['post_id'];
			$imgPath = $row['file'];

			$basename = basename($imgPath);
			$imgPathExtracted = "postImages/" . $basename;

			$sql_query = "DELETE FROM scholar_posts WHERE post_id='$postID' ";
			if(mysqli_query($connection, $sql_query))
			{
				if ($imgPath != "NONE")
				{
					if (file_exists($imgPathExtracted))
					{
						if(!unlink($imgPathExtracted))
						{
							$response["message"] = "Error Deleting Image";
				 			echo json_encode($response);
						}
						else
						{
				 			$response["message"] = "Image and Post Successfully Deleted";
				 			echo json_encode($response);
						}
						
					}
					else
					{
						$response["message"] = "File Exists but Can't be Deleted - Post deleted.";
				 		echo json_encode($response);
					}

				}
				
				$response["message"] = "Post Deleted Successfully";
		 		echo json_encode($response);
			}
			else
			{		
				$response["message"] = "Deletion Failed";
		 		echo json_encode($response);
			}
	
		}
		else
		{
			$response["message"] = "Query Failed To Run";
			 echo json_encode($response);
		}


		mysqli_close($connection);

	}
	else{
		echo 'error - not receiving POST request';
	}

?>