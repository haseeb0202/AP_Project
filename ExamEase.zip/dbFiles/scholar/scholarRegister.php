<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){
			$name = $_POST['name'];
			$email = $_POST['email'];
			$username = $_POST['username'];
			$password = $_POST['password'];
			$sect = $_POST['sect'];
			$age = $_POST['age'];
			$contact_number = $_POST['contact'];


			////////////////////////////////////////////////////////////////
			$image = null;			//actual image came from android code in byte array or watever form
			$certificate  = null;	//actual certificate came from android code in decoded/encoded or watever form

			$profile_pic = null;	//DEFAULT pic path to insert in table in case prof pic is not set
			$certificatePath = null;	//DEFAULT certificate path to insert in table in case certificate is not set

			//if during registration scholar attach both image and certificate at once
			if(isset($_POST['image']) && isset($_POST['certificate']) )
			{

				$image = $_POST['image'];
				$certificate = $_POST['certificate'];

				$path1 = "scholarPictures/$username.png";
				$path2 = "scholarCertificates/$username.png";
				
				$profile_pic = "http://amber.webs.net.pk/~askislam/scholarScripts/$path1";
				$certificatePath = "http://amber.webs.net.pk/~askislam/scholarScripts/$path2";
		
			}
			elseif (isset($_POST['image']) ) {
				# code...
				$image = $_POST['image'];
				$path1 = "scholarPictures/$username.png";
				$profile_pic = "http://amber.webs.net.pk/~askislam/scholarScripts/$path1";
			}
			elseif (isset($_POST['certificate']) ) {
				# code...
				$certificate = $_POST['certificate'];
				$path2 = "scholarCertificates/$username.png";
				$certificatePath = "http://amber.webs.net.pk/~askislam/scholarScripts/$path2";
			}

			
			require_once('connect.php');
			$sql = "SELECT * FROM scholar_users_temp WHERE username='$username' ";
			//$sql ="SELECT username FROM scholar_users_temp ORDER BY id ASC";

			$check = mysqli_fetch_array(mysqli_query($connection,$sql));

			
			if(isset($check))
			{
				$response["message"] = "Username already exists. Please chose another one.";
				echo json_encode($response);
			}
			else
			{
				$sql_query = "INSERT into scholar_users_temp(name, email, username, password, sect, age, contact_number,
				 profile_pic, certificate) 
				VALUES
				('$name', '$email','$username', '$password', '$sect', '$age', '$contact_number', '$profile_pic', '$certificatePath')";			

				if(mysqli_query($connection, $sql_query)){
					
					if($image != null && $certificate != null)
					{
						file_put_contents($path1,base64_decode($image));
						file_put_contents($path2,base64_decode($certificate));
					}
					elseif ($image != null) {
						# code...
						file_put_contents($path1,base64_decode($image));
					}
					elseif ($certificate != null) {
						# code...
						file_put_contents($path2,base64_decode($certificate));
					}

					$response["message"] = "Your Request for Approval as a Scholar has been sent to Administrator. You'll be notified once its approved.";
					echo json_encode($response);
				}
				else
				{
					//echo 'oops! Please try again!';
					$response["message"] = "Something went wrong";	
					//open register activity again to register. cant use old form data to register again
					echo json_encode($response);
				}
			}

			mysqli_close($connection);

	}
	else{
		echo 'error - not receiving POST request';
	}

?>