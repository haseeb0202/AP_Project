<?php


	require_once('connect.php');

	$pid=$_POST['postid'];
	$userid = $_POST['userid'];
	$comment = $_POST['comment'];
	$user_type = $_POST['usertype'];

	$tag=$_POST['tag'];
	$sid = $_POST['sid'];
	//$sid = 40;


	if($tag == "comment")
	{
		$sql = "INSERT INTO `askislam_main`.`comments` ( `post_id`,`user_id`, `comment`, `user_type`) 
				VALUES ('$pid', '$userid', '$comment', '$user_type');";

	  	mysqli_query($connection , $sql);
	}

	$sql = "SELECT * FROM comments WHERE post_id='$pid' ";
	$result = mysqli_query($connection , $sql);
	$response= array();

	if(mysqli_num_rows($result) > 0)
	{
		while($row = mysqli_fetch_array($result) )
		{
			if($row[4]=="scholar")	//row 4 is: user type    -- row 2 is post_id
			{
				$sql = "SELECT name, username, profile_pic FROM scholar_users WHERE scholar_id = $row[2] ";
		        $result1 = mysqli_query($connection, $sql);
			       
	          	$row1 = mysqli_fetch_array($result1);
	          	$user = $row1["name"];
	          	$username = $row1["username"];	//new line added
	          	$profilepic = $row1["profile_pic"];
			}
			else
			{
				$sql = "SELECT fname, profilepic FROM users where id = $row[2]";
			    $result1 = mysqli_query($connection, $sql);
			       
		        $row1 = mysqli_fetch_array($result1);
		        $user = $row1["fname"];
		        //$username = $row1["username"];	//currently username column does not exist in users table
		        $username = $row1["fname"];			//temporary here the user's first name will be shown
		        $profilepic = $row1["profilepic"];	//in users table profile_pic column name has no underscore - make consistent
			}

			array_push($response, array("comment"=>$row[3],"user"=>$user, "username"=>$username, "profilepic"=>$profilepic) );
		}

		echo json_encode(array("comments"=>$response,"success"=>1 ));
	}
	else
	{
		$response["success"] = 0;
		$response["message"] = "No comment";
		echo json_encode($response);
	}
?>

