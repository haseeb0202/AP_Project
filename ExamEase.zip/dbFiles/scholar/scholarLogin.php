<?php

	require_once "connect.php";

	$username = $_POST["username"];
	$password = $_POST["password"];

	$sql_query = "SELECT * from scholar_users WHERE username='$username' AND password='$password'";


	$result = mysqli_query($connection, $sql_query);

	if(mysqli_num_rows($result) > 0)
	{
		$row = mysqli_fetch_assoc($result);

		$id = $row['scholar_id'];
		$name = $row['name'];
		$picURL = $row['profile_pic'];
		$username = $row['username'];
		
		$response["message"] = "Login Successful...";
		$response["sid"] = $id;		//passing the id of the logged in scholar to android for maintaining session
		$response["sname"] = $name;
		$response["spicURL"] = $picURL;
		$response["susername"] = $username;

 		echo json_encode($response);
	}
	else
	{
		$response["message"] = "Login Failed...";
 		echo json_encode($response);
	}

/*
if($_SERVER['REQUEST_METHOD']=='POST'){
		
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if($username == '' || $password == ''){
			echo 'please fill all values';
		}else{
			require_once('connect.php');
			$sql = "SELECT * FROM admin_users WHERE username='$username' ";
			
			$check = mysqli_fetch_array(mysqli_query($connection,$sql));
			
			if(isset($check)){
				echo 'Login Successful!';
			}

			mysqli_close($connection);
		}
}else{
echo 'error - not receiving POST request';
}
*/

?>