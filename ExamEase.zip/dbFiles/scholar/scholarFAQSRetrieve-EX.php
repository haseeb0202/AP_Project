<?php

s
	if ($_SERVER['REQUEST_METHOD'] == 'POST' )
	{
		require_once "connect.php";

		$sid = $_POST['scholarid'];


		$sql_query = "SELECT * FROM faqs WHERE scholar_id = '$sid' ORDER BY faq_id DESC";
		$result = mysqli_query($connection, $sql_query);

		$response = array();

		while($row = mysqli_fetch_array($result))
		{
			//$response["s_question"] = $row['question'];
			//$response["s_answer"]	= $row['answer'];
			//$response["s_category"] = $row['category'];
			array_push($response, array("s_question"=>$row[2], "s_answer"=>$row['answer'], "s_category"=>$row[4], 
																					"s_name"=>$row['scholar_name']  ) );
		}


		echo json_encode(array("server_response"=>$response));

		mysqli_close($connection);


	}
	else
		echo "NOT RECEIVING POST REQUEST";









?>