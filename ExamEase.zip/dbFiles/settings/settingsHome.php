<?php
require_once "connect.php";


if($_SERVER["REQUEST_METHOD"] == 'POST')
{


	$sid;

	$postcounts = "0";
	$followerscounts = "0";

	//LOADING BASIC SETTINGS FOR SETTINGS HOME CLASS - Followers, Posts, FAQs  = COUNTS
	if(isset($_POST['scholarid']) && isset($_POST['showsettings']) )
	{
		$sid = $_POST['scholarid'];
		$susername = $_POST['susername'];

		/////////////////GETTING POSTS COUNT FOR A SCHOLAR ID//////////////////////////
		$sql_query1 = "SELECT COUNT(post) FROM scholar_posts WHERE scholar_id = '$sid' ";
		$result1 = mysqli_query($connection, $sql_query1);

		$row1 = mysqli_fetch_array($result1);
		$postcounts = $row1[0];

		$response["postcounts"] = $postcounts;


		/////////////////GETTING FOLLOWERS COUNT FOR A SCHOLAR ID//////////////////////////
		$sql_query2 = "SELECT COUNT(user_id) FROM follow WHERE scholar_id = '$sid' ";
		$result2 = mysqli_query($connection, $sql_query2);

		$row2 = mysqli_fetch_array($result2);
		$followerscounts = $row2[0];

		$response["followerscounts"] = $followerscounts;


		/////////////////GETTING POSTED FAQS COUNT FOR A SCHOLAR ID//////////////////////////
		$sql_query3 = "SELECT COUNT(q_id) FROM questions_answered WHERE s_username = '$susername' ";
		$result3 = mysqli_query($connection, $sql_query3);

		$row3 = mysqli_fetch_array($result3);
		$questionsaskedcounts = $row3[0];

		$response["questionsaskedcounts"] = $questionsaskedcounts;


		///////////////////////////////////////////////////////////////////////////////
		echo json_encode($response);


	}
	elseif (isset($_POST['scholarid']) && isset($_POST['deactivatekey']))
	{
		# code...

		$sid = $_POST['scholarid'];

		deletePosts($sid, $connection);
		deleteFollowers($sid, $connection);
		deleteComments($sid, $connection);
		deleteScholar($sid, $connection);


		$response["message"] = "ACCOUNT DEACTIVATED SUCCESSFULLY";
		echo json_encode($response);


	}	//End of elseif



	mysqli_close($connection);



}	//END OF SERVER REQUEST == POST
else
	{
		echo 'error - not receiving POST request';
	}






	///////////////////////////////////FUNCTIONS//////////////////////////////////////////////////////

	function deletePosts($sidx, $connection)
	{
		$sid = $sidx;

		//getting file image path of the post one by one and deleting files/images from the folder where exists
		$get_file_path_query = "SELECT file FROM scholar_posts WHERE scholar_id = '$sid' ";	//return all the file rows
		$result = mysqli_query($connection, $get_file_path_query);
		$filePaths = array();
		
		$index = 0;
		$row = null;

		while($row = mysqli_fetch_array($result) )	//this will store all the rows data in an associative array
		{
			$filePaths[$index] = $row;
			$index++;
		}
		//The above loop goes through each row and stores it as an element in the new array you had made. 


		$imgPathExtracted = "NONE";
		//The below loop will delete all the files from the server by getting their image paths one by one
		while($index > 0)
		{
			$imgPath = $filePaths[$index-1][0];	//this will get the $index position row and first column (file)
			$basename = basename($imgPath);
			$imgPathExtracted = "../scholarScripts/postImages/" . $basename;


			if ($imgPath != "NONE")
			{
				if (file_exists($imgPathExtracted))
				{
					unlink($imgPathExtracted);
				}
				else
				{
					$response["message"] = "File Exists but Can't be Deleted";
			 		echo json_encode($response);
				}

			}
			
			$index--;

		} //END OF WHILE LOOP

		//Once all the images are deleted from the server scholarScripts/postImages folder then delete all posts from mysql table
		$delete_posts_query = "DELETE FROM scholar_posts WHERE scholar_id = '$sid' ";
		mysqli_query($connection, $delete_posts_query);


	}	//END OF FUNCTION deletePost()


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteFollowers($sid, $connection)
	{
		$delete_followers = "DELETE FROM follow WHERE scholar_id = '$sid' ";
		mysqli_query($connection, $delete_followers);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteComments($sid, $connection)
	{
		$delete_comments_query = "DELETE FROM comments WHERE user_id = '$sid' AND user_type = 'scholar'  ";
		mysqli_query($connection, $delete_comments_query);
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteScholar($sid, $connection)
	{
		//FIRST DELETE SCHOLAR PROFILE PICTURE AND CERTIFICATE FROM SERVER FOLDER
		$get_profile_pic_path = "SELECT profile_pic, certificate FROM scholar_users WHERE scholar_id = '$sid' ";
		$result = mysqli_query($connection, $get_profile_pic_path);
		
		$row = mysqli_fetch_array($result);
		$imgPath = $row[0];	//Profile pic column
		$certPath = $row[1];//Certificate pic column

		$basename1 = basename($imgPath);
		$basename2 = basename($certPath);
		$imgPathExtracted = "../scholarScripts/scholarPictures/" . $basename1;
		$certPathExtracted = "../scholarScripts/scholarCertificates/" . $basename2;


			if ($imgPath != "NONE")
			{
				if (file_exists($imgPathExtracted))
					unlink($imgPathExtracted);	

			}

			if ($certPath != "NONE")
			{
				if (file_exists($certPathExtracted))
					unlink($certPathExtracted);
			}


		//NOW DELETE SCHOLAR INFO FROM TABLE
		$delete_user_query  = "DELETE FROM scholar_users WHERE scholar_id = '$sid' ";
		mysqli_query($connection, $delete_user_query);

	}

	
	





?>
