<?php

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		require_once "connect.php";

		$sid = $_POST['scholarid'];


		//GET ALL THE USER IDS THAT ARE AGAINST (FOLLOWING) A SPECIFIC SCHOLAR AND STORE IN AN ARRAY
		$sql_query = "SELECT user_id FROM follow WHERE scholar_id = '$sid' ";
		$result = mysqli_query($connection, $sql_query);
		$userIDS = array();

		$index = 0;

		while($row = mysqli_fetch_array($result))
		{
			//array_push($userIDS, $row['user_id']);
			$userIDS[$index] = $row;
			$index++;
		}


		$response = array();

		while($index > 0)
		{
			$userid = $userIDS[$index-1][0];

			$sql = "SELECT fname, email, profilepic FROM users WHERE id = '$userid' ";
			$res = mysqli_query($connection, $sql);

			$row = mysqli_fetch_array($res);
			$userName = $row['fname'];
			$userEmail = $row['email'];
			$userPic = $row['profilepic'];

			array_push($response, array("u_name"=>$row['fname'],"u_email"=>$row['email'], "u_image"=>$row['profilepic'] ) );

			$index--;

		}

		echo json_encode(array("server_response"=>$response));

	}
	else
	{
		echo 'error - not receiving POST request';
	}




?>