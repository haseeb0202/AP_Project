<?php

require "init.php";

$email = $_POST['email'];
$password = $_POST['password'];



/*
$email = "rubinabatool@gmail.com";
$password = "seecs@123";
*/

$sql = "select * from users where email = '$email' AND password='$password'";

$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1)
{
      $row = mysqli_fetch_assoc($result);

      $response["message"] = "Login Successful...";

      $response["id"] = $row["id"];
      $response["name"]= $row["fname"] . " " . $row["lname"];
      $response["email"] = $row["email"];
      $response["profilepic"] = $row["profilepic"];

            /*
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

$user=$row["name"];

$user = array();
            $user["id"] = $row["id"];
	      $user["name"]= $row["fname"] . " " . $row["lname"];
            $user["email"] = $row["email"];
            $user["profilepic"] = $row["profilepic"];

			
			
		$response["success"] = 1;
            $response["message"] = "Login Successful...";
 
            // user node
            $response["user"] = array();
 
            //array_push($response["user"], $user);
 */
            // echoing JSON response
           
            echo json_encode($response);

}
else
{
//$response["success"] = 0;
$response["success"] = 0;

$response["message"] = "Invalid Email or Password";
 
 // echo no users JSON
 echo json_encode($response);

}


?>