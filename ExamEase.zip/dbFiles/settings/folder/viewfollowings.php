<?php
require_once "init.php";

$uid=$_POST["id"];
//$uid=20;

$sql = "select scholar_id from follow where user_id='$uid'";
$r = mysqli_query($con,$sql);
$following= array();

while($row=mysqli_fetch_array($r,MYSQLI_ASSOC))
{
array_push($following,$row['scholar_id']);
}

$sql_query = "SELECT * FROM scholar_users where scholar_id in (" . implode(",", $following) . ")";

$result = mysqli_query($con, $sql_query);

if(mysqli_num_rows($result)>0)
{
$response["server_response"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
       

        $scholar = array();
        
        $scholar["s_name"] = $row["name"];
		 $scholar["s_image"] = $row["profile_pic"];
		  $scholar["s_email"] = $row["email"];
        $scholar["s_id"] = $row["scholar_id"];
        $scholar["s_username"] = $row["username"];


        // push single product into final response array
        array_push($response["server_response"], $scholar);
    }
         
			
			$response["success"] = 1;
 
         
            echo json_encode($response);
}

else
{
$response["success"] = 0;
$response["message"] = "You are not following any scholar";
 
 // echo no users JSON
 echo json_encode($response);

}

?>