<?php
require "init.php";
$sid = $_POST['userid'];
//$sid=20;
$sql_query2 = "SELECT COUNT(scholar_id) FROM follow WHERE user_id = '$sid' ";
		$result2 = mysqli_query($con, $sql_query2);


		$row2 = mysqli_fetch_array($result2);
		$followingscount = $row2[0];

              
		$response["followingscount"] =$followingscount;

echo json_encode($response);

?>