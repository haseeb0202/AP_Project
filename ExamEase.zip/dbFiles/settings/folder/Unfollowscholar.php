<?php

require "init.php";
$sid = $_POST['id'];
$uid =  $_POST['user_id'];


$sql_query="DELETE FROM follow WHERE scholar_id='$sid' AND user_id='$uid';";

if(mysqli_query($con,$sql_query))
{

$response["success"] = 1;
 
 // echo no users JSON
 echo json_encode($response);

}

else
{
$response["message"] = "Something went Wrong ";
$response["success"] = 0;
echo json_encode($response);

}


?>