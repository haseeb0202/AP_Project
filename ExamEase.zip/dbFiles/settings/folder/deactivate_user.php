<?php

require_once "init.php";

if (isset($_POST['scholarid']) && isset($_POST['deactivatekey']))
	{
		# code...

		$sid = $_POST['scholarid'];

		deleteFollowings($sid, $con);
		deleteComments($sid, $con);
		deleteUser($sid, $con);


		$response["message"] = "ACCOUNT DEACTIVATED SUCCESSFULLY";
		echo json_encode($response);


	}	//End of elseif



	//END OF SERVER REQUEST == POST
else
	{
		echo 'error - not receiving POST request';
	}



	///////////////////////////////////FUNCTIONS//////////////////////////////////////////////////////



	function deleteFollowings($sid, $connection)
	{
		$delete_followers = "DELETE FROM follow WHERE user_id = '$sid' ";
		mysqli_query($connection, $delete_followers);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteComments($sid, $connection)
	{
		$delete_comments_query = "DELETE FROM comments WHERE user_id = '$sid' AND user_type = 'user'  ";
		mysqli_query($connection, $delete_comments_query);
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteUser($sid, $connection)
	{
		//FIRST DELETE SCHOLAR PROFILE PICTURE AND CERTIFICATE FROM SERVER FOLDER
		$get_profile_pic_path = "SELECT profilepic FROM users WHERE id = '$sid' ";
		$result = mysqli_query($connection, $get_profile_pic_path);
		
		$row = mysqli_fetch_array($result);
		$imgPath = $row[0];	//Profile pic column
		

		$basename1 = basename($imgPath);
		
		$imgPathExtracted = "../userscripts/userpictures/" . $basename1;
		


			if ($imgPath != "NONE")
			{
				if (file_exists($imgPathExtracted))
					unlink($imgPathExtracted);	

			}

		


		//NOW DELETE SCHOLAR INFO FROM TABLE
		$delete_user_query  = "DELETE FROM users WHERE id = '$sid' ";
		mysqli_query($connection, $delete_user_query);

	}

	
	





?>