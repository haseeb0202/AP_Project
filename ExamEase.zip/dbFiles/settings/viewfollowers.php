<?php
require_once "init.php";

$sid=$_POST["id"];
//$sid=8;

$sql = "select user_id from follow where scholar_id='$sid'";
$r = mysqli_query($con,$sql);
$followers= array();

while($row=mysqli_fetch_array($r,MYSQLI_ASSOC))
{
array_push($followers,$row['user_id']);
}


$sql_query = "SELECT * FROM users where id in (" . implode(",", $followers) . ")";

$result = mysqli_query($con, $sql_query);

if(mysqli_num_rows($result)>0)
{

$response["server_response"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
       
        $user = array();
        
        $user["s_name"] = $row["fname"];
		 $user["s_image"] = $row["profilepic"];
		  $user["s_email"] = $row["email"];
        $user["s_id"] = $row["id"];


        // push single product into final response array
        array_push($response["server_response"], $user);
    }
         
			
			$response["success"] = 1;
 
         
            echo json_encode($response);
}

else
{
$response["success"] = 0;
$response["message"] = "YOU DO NOT HAVE ANY FOLLOWERS YET";
 
 // echo no users JSON
 echo json_encode($response);

}


?>