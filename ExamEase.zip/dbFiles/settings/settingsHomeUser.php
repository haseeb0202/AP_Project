<?php
require_once "connect.php";


if($_SERVER["REQUEST_METHOD"] == 'POST')
{

	$uid;
	$followingscounts = "0";

	//LOADING BASIC SETTINGS FOR ACCOUNT HOME USER CLASS - Followings, Asked Questions = COUNTS
	if(isset($_POST['userid']) && isset($_POST['showsettings']) )
	{
		$uid = $_POST['userid'];

		/////////////////GETTING FOLLOWINGS COUNT FOR A SCHOLAR ID//////////////////////////
		$sql_query1 = "SELECT COUNT(scholar_id) FROM follow WHERE user_id = '$uid' ";

		$result1 = mysqli_query($connection, $sql_query1);

		$row1 = mysqli_fetch_array($result1);
		$followingscounts = $row1[0];

		$response["followingscounts"] = $followingscounts;


		/////////////////GETTING POSTED QUESTIONS COUNT FOR A USER ID//////////////////////////
		$sql_query2 = "SELECT COUNT(q_id) FROM questions_asked WHERE user_id = '$uid' ";
		$result2 = mysqli_query($connection, $sql_query2);

		$row2 = mysqli_fetch_array($result2);
		$questionsaskedcounts = $row2[0];

		$response["questionsaskedcounts"] = $questionsaskedcounts;


		///////////////////////////////////////////////////////////////////////////////
		echo json_encode($response);


	}
	elseif (isset($_POST['userid']) && isset($_POST['deactivatekey']))
	{
		# code...

		$uid = $_POST['userid'];

		deleteFollowings($uid, $connection);
		deleteComments($uid, $connection);
		deleteUser($uid, $connection);

		$response["message"] = "ACCOUNT DEACTIVATED SUCCESSFULLY";
		echo json_encode($response);


	}	//End of elseif



	mysqli_close($connection);



}	//END OF SERVER REQUEST == POST
else
	{
		echo 'error - not receiving POST request';
	}






	///////////////////////////////////FUNCTIONS//////////////////////////////////////////////////////



	function deleteFollowings($uid, $connection)
	{
		$delete_followings = "DELETE FROM follow WHERE user_id = '$uid' ";
		mysqli_query($connection, $delete_followings);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteComments($uid, $connection)
	{
		$delete_comments_query = "DELETE FROM comments WHERE user_id = '$uid' AND user_type = 'user'  ";
		mysqli_query($connection, $delete_comments_query);
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function deleteUser($uid, $connection)
	{
		//FIRST DELETE USER PROFILE PICTURE FROM SERVER FOLDER
		$get_profile_pic_path = "SELECT profilepic FROM users WHERE id = '$uid' ";
		$result = mysqli_query($connection, $get_profile_pic_path);
		
		$row = mysqli_fetch_array($result);
		$imgPath = $row[0];	//Profile pic column
		

		$basename1 = basename($imgPath);
		
		$imgPathExtracted = "../userscripts/userpictures/" . $basename1;
		
			if ($imgPath != "NONE")
			{
				if (file_exists($imgPathExtracted))
					unlink($imgPathExtracted);	

			}

		//NOW DELETE USER INFO FROM TABLE
		$delete_user_query  = "DELETE FROM users WHERE id = '$uid' ";
		mysqli_query($connection, $delete_user_query);

	}
	





?>
