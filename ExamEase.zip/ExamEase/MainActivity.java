package ap.project;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import net.lostt.kat.askislam.Admin.AdminHome.AdminHomeLV;
import net.lostt.kat.askislam.Admin.AdminLogin;
import net.lostt.kat.askislam.Admin.AdminRegister;
import net.lostt.kat.askislam.Scholar.ScholarHome.ScholarHome;
import net.lostt.kat.askislam.Scholar.ScholarLogin;
import net.lostt.kat.askislam.Scholar.ScholarRegister;
import net.lostt.kat.askislam.Users.User_home_screen;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;


public class MainActivity extends AppCompatActivity {

    private static final String USER_LOGIN_URL = "http://amber.webs.net.pk/~askislam/userscripts/user_login.php";
    private static final String SCHOLAR_LOGIN_URL = "http://amber.webs.net.pk/~askislam/scholarScripts/scholarLogin.php";
    private static final String ADMIN_LOGIN_URL = "http://amber.webs.net.pk/~askislam/adminScripts/adminLogin.php";
    private String LOGIN_URL;



    EditText MainEmailUsername, MainPassword;
    RadioGroup UserTypeGroup;
    RadioButton UserType;

    String mainEmailUsername, mainPassword, userType;

    Button LoginBTN;

    TextView SignupNow;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MainEmailUsername = (EditText) findViewById(R.id.main_login_username_email);
        MainPassword = (EditText) findViewById(R.id.main_login_password);
        UserTypeGroup = (RadioGroup) findViewById(R.id.UserType);

        LoginBTN = (Button) findViewById(R.id.loginbutton);
        LoginBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processLogin();
            }
        });

        SignupNow = (TextView) findViewById(R.id.signupnow);
        SignupNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), choice_register_class.class));
            }
        });


        final SharedPreferences sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE);
        String sid = sharedPreferences.getString("SCHOLAR_ID", null);
        String uid = sharedPreferences.getString("USER_ID", null);
        String aid = sharedPreferences.getString("ADMIN_ID", null);
        if(sid != null)
        {
            finish();
            Intent i = new Intent(getApplicationContext(), ScholarHome.class);
            startActivity(i);
        }
        else if (uid != null)
        {
            finish();
            startActivity(new Intent(getApplicationContext(), User_home_screen.class));
        }
        else if (aid != null)
        {
            finish();
            startActivity(new Intent(getApplicationContext(), AdminHomeLV.class));
        }



    }   //end of onCreate();

    //////////////////////////////////////////////////////////////

    private void processLogin()
    {
        mainEmailUsername = MainEmailUsername.getText().toString();
        mainPassword = MainPassword.getText().toString();

        int selectedId = UserTypeGroup.getCheckedRadioButtonId();
        UserType = (RadioButton) findViewById(selectedId);
        userType = UserType.getText().toString();

        if(userType.equals("User"))
            LOGIN_URL = USER_LOGIN_URL;
        else if (userType.equals("Scholar"))
            LOGIN_URL = SCHOLAR_LOGIN_URL;
        else if (userType.equals("Admin"))
            LOGIN_URL = ADMIN_LOGIN_URL;
        else
            LOGIN_URL = "";

        ///CHECKS
        if(mainEmailUsername.equals("") || mainPassword.equals(""))
            Toast.makeText(this, "Please Enter Required Fields", Toast.LENGTH_SHORT).show();
        else if (!UserType.isChecked())
            Toast.makeText(this, "Please Select User Type", Toast.LENGTH_SHORT).show();
        else
            doLogin();

    }

    ////////////////////////////////////////////////////////////
    JSONObject jsonObject;

    private void doLogin()
    {
        class DoLogin extends AsyncTask<Void, Void, JSONObject>
        {
            ProgressDialog logging;
            RequestHandler rh = new RequestHandler();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                logging = ProgressDialog.show(MainActivity.this, "Logging you in", "Please wait...", true, true);
            }

            @Override
            protected JSONObject doInBackground(Void... params) {

                HashMap<String,String> credentials = new HashMap<>();
                if(userType.equals("Scholar") || userType.equals("Admin"))
                {
                    credentials.put("username", mainEmailUsername);
                    credentials.put("password", mainPassword);
                }
                else if (userType.equals("User"))
                {
                    credentials.put("email", mainEmailUsername);
                    credentials.put("password", mainPassword);
                }


                String result = rh.sendPostRequest(LOGIN_URL, credentials, MainActivity.this);
                try {
                    jsonObject = new JSONObject(result);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return jsonObject;
            }


            @Override
            protected void onPostExecute(JSONObject jsonObject) {
                super.onPostExecute(jsonObject);

                logging.dismiss();

                String result = "";

                try {
                    result = jsonObject.getString("message");

                    if(result.equals("Login Successful...") && userType.equals("Scholar") )
                    {
                        String sid = jsonObject.getString("sid");
                        String sname = jsonObject.getString("sname");
                        String spicURL = jsonObject.getString("spicURL");
                        String susername = jsonObject.getString("susername");

                        final SharedPreferences sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE);
                        sharedPreferences.edit().putString("SCHOLAR_ID", sid).apply();
                        sharedPreferences.edit().putString("SCHOLAR_NAME", sname).apply();
                        sharedPreferences.edit().putString("SCHOLAR_PIC_URL", spicURL).apply();
                        sharedPreferences.edit().putString("SCHOLAR_USERNAME", susername).apply();
                        finish();
                        Intent i = new Intent(getApplicationContext(), ScholarHome.class);
                        startActivity(i);
                    }
                    else if (result.equals("Login Successful...") && userType.equals("User") )
                    {
                        int id = jsonObject.getInt("id");
                        String uid = jsonObject.getString("id");
                        String fname = jsonObject.getString("name");
                        //String lnames = jsonObject.getString(lname_KEY);
                        String emails = jsonObject.getString("email");
                        String profilepics = jsonObject.getString("profilepic");

                        final SharedPreferences sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE);
                        sharedPreferences.edit().putString("USER_ID", uid).apply();
                        sharedPreferences.edit().putString("USER_FNAME", fname).apply();
                        //sharedPreferences.edit().putString("USER_LNAME", lnames).apply();
                        sharedPreferences.edit().putString("USER_PIC", profilepics).apply();
                        sharedPreferences.edit().putString("USER_EMAIL", emails).apply();
                        Intent i = new Intent(getApplicationContext(), User_home_screen.class);
                        i.putExtra("uid", id);
                        i.putExtra("user_type", userType);
                        startActivity(i);
                    }
                    else if (result.equals("Login Successful...") && userType.equals("Admin") )
                    {
                        String aid = jsonObject.getString("aid");
                        final SharedPreferences sharedPreferences = getSharedPreferences("AdminLogin", Context.MODE_PRIVATE);
                        sharedPreferences.edit().putString("ADMIN_ID", aid).apply();
                        finish();
                        Intent i = new Intent(getApplicationContext(), AdminHomeLV.class);
                        startActivity(i);
                    }

                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }


        }   //end of class

        DoLogin dl = new DoLogin();
        dl.execute();

    }   //end of method



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        switch (id) {
            case R.id.admin_register:
                Intent i = new Intent(this, AdminRegister.class);
                startActivity(i);
                break;
            case R.id.admin_login:
                Intent i2 = new Intent(this, AdminLogin.class);
                startActivity(i2);
                break;
            case R.id.scholar_register:
                Intent i3 = new Intent(this, ScholarRegister.class);
                startActivity(i3);
                break;
            case R.id.scholar_login:
                Intent i4 = new Intent(this, ScholarLogin.class);
                startActivity(i4);
                break;
            default:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }




}
