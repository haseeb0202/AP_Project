package ap.project;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import net.lostt.kat.askislam.Scholar.ScholarRegister;
import net.lostt.kat.askislam.Users.Registration;


public class choice_register_class extends AppCompatActivity {

    Button scholr_register, user_register;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choice_user_scholar_registration);

        scholr_register = (Button) findViewById(R.id.scholar_registerbtn);
        user_register = (Button) findViewById(R.id.user_registerbtn);

        scholr_register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ScholarRegister.class);
                startActivity(i);

            }
        });


        user_register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Registration.class);
                startActivity(i);

            }
        });
    }




}