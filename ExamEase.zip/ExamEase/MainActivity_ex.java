package ap.project;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import net.lostt.kat.askislam.Admin.AdminLogin;
import net.lostt.kat.askislam.Admin.AdminRegister;
import net.lostt.kat.askislam.FAQs.FAQSHome;
import net.lostt.kat.askislam.Scholar.ScholarLogin;
import net.lostt.kat.askislam.Scholar.ScholarRegister;

public class MainActivity_ex extends AppCompatActivity {

    Button btnToFAQSHome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ex);

        ActionBar actionBar = getSupportActionBar();
        //actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(true); //Optional
        actionBar.setTitle("ASK ISLAM");
        actionBar.setIcon(R.drawable.scholarhome_post_upload_image_icon2);

        btnToFAQSHome = (Button) findViewById(R.id.faqs_home);
        btnToFAQSHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), FAQSHome.class));
            }
        });






    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        switch (id) {
            case R.id.admin_register:
                Intent i = new Intent(this, AdminRegister.class);
                startActivity(i);
                break;
            case R.id.admin_login:
                Intent i2 = new Intent(this, AdminLogin.class);
                startActivity(i2);
                break;
            case R.id.scholar_register:
                Intent i3 = new Intent(this, ScholarRegister.class);
                startActivity(i3);
                break;
            case R.id.scholar_login:
                Intent i4 = new Intent(this, ScholarLogin.class);
                startActivity(i4);
                break;
            default:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }



}
