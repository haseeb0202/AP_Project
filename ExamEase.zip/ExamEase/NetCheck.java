package ap.project;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class NetCheck {
    int resCode = -1;
    private Context context;
    public NetCheck(Context context)
    {
        this.context= context;

    }

    public boolean checkingnetwork() {

        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();


        if(activeNetworkInfo != null && activeNetworkInfo.isConnected())
        {
            try {
                URL url = new URL("https://www.google.com.pk/");
                HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                urlc.setConnectTimeout(3000);
                urlc.setInstanceFollowRedirects(true);
                urlc.connect();
                resCode = urlc.getResponseCode();

                if (resCode == HttpURLConnection.HTTP_OK) {
                    return true;

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return false;

    }


}

